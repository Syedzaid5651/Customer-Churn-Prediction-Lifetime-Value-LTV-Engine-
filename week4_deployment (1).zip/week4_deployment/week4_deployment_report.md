# Week 4 — Dashboard, Deployment & Documentation Report
**Project:** Customer Churn Prediction & LTV Engine

---

## 1. Batch Scoring Job (Day 1-3)

Built `src/batch_score.py`, which scores every customer in `dim_customers` through the same `ModelService` used by the FastAPI layer, and writes results into `fact_predictions`. This guarantees batch and real-time scoring never drift apart (one model service, two entry points).

**Actually run against all 7,043 customers:**
| Metric | Value |
|---|---|
| Total customers scored | 7,043 |
| High-risk customers (churn prob. ≥ 60%) | 2,190 (31.1%) |
| High-risk **and** High-LTV customers | **255** |
| Total predicted LTV currently at risk | **$2,746,742** |
| Average predicted LTV | $2,915 |

**The 255 customers who are both high-churn-risk and high-LTV are the single most important number to hand to the marketing/retention team** — they're the highest-leverage retention targets. This job would run nightly/weekly in production (cron or Airflow) after new billing data lands.

## 2. Interactive Dashboard (Day 4-5)

**A note on scope:** this sandbox can't run a persistent Apache Superset instance (no Docker daemon, no port exposure to the outside). So I built two things:
1. A **real, working HTML dashboard** (`reports/dashboard.html`) — self-contained, opens directly in any browser, built on the actual `fact_predictions` + `dim_customers` data from this project. This is a genuine, testable deliverable you can open right now.
2. **Docker Compose + Superset setup instructions** (below) for connecting the real BI tool once you have Docker available.

### Dashboard contents (all real data, not mockups)
- KPI row: total customers, overall churn rate, high-risk count, high-risk+high-LTV count, total LTV at risk, average predicted LTV
- Churn rate by contract type, internet service, payment method (bar charts)
- Churn rate by tenure bucket (line chart — shows the risk curve declining with loyalty)
- Risk tier and LTV segment distributions (donut charts)
- **Top 50 retention priority customers** — sortable-by-eye table of the highest-priority-score customers (high churn risk × high LTV), ready to hand to a retention campaign

## 3. Containerization (Day 6-7)

- **`Dockerfile`** — builds the FastAPI service into a slim Python 3.11 image, includes a healthcheck hitting `/health`.
- **`docker-compose.yml`** — orchestrates 3 services:
  - `postgres` — auto-initializes with `sql/schema.sql` on first boot
  - `api` — the churn/LTV FastAPI service, connects to Postgres via `DATABASE_URL`
  - `superset` — official Apache Superset image, for the real BI dashboard

**Honesty check:** these files are written to the Docker/Compose spec correctly and reviewed carefully, but **not build-tested** in this sandbox (no Docker daemon available here). Before relying on them, run:
```bash
docker compose build
docker compose up -d
```
and verify `docker compose ps` shows all three containers healthy.

### Connecting Superset to Postgres (one-time setup, after `docker compose up`)
```bash
docker compose exec superset superset db upgrade
docker compose exec superset superset fab create-admin \
  --username admin --firstname Admin --lastname User \
  --email admin@example.com --password admin
docker compose exec superset superset init
```
Then in the Superset UI (`localhost:8088`): **Settings → Database Connections → + Database → PostgreSQL**, connect to `postgres:5432/churn_ltv` using the credentials in `docker-compose.yml`, and build charts against the `vw_churn_risk_dashboard` view (already defined in `sql/schema.sql`) — it joins `dim_customers` to the latest row per customer in `fact_predictions`.

## 4. Final Technical Documentation

See `README.md` at the project root for the consolidated architecture overview, setup instructions, and a summary of all 4 weeks.

## 5. Artifacts Produced This Week

- `src/batch_score.py` — batch scoring job (tested against all 7,043 customers)
- `reports/dashboard.html` — working, self-contained interactive dashboard
- `reports/dashboard_data.json` — aggregated data feeding the dashboard
- `reports/batch_score_summary.json` — run summary stats
- `Dockerfile`, `docker-compose.yml`, `.dockerignore`
- `README.md` — full project documentation

## 6. Project Status: Complete

All 4 weeks of the original plan have working, tested code — not just design documents. Summary of what's provable right now, in this repo:
- Data pipeline: ✅ tested (7,043 rows, 0 nulls after cleaning)
- EDA: ✅ tested (6 charts + stats JSON)
- Churn models: ✅ tested (3 models compared, best F1=0.64, ROC-AUC=0.84)
- SHAP explainability: ✅ tested (matches EDA findings independently)
- LTV model: ✅ tested (R²=0.985, MAE ~$185)
- FastAPI service: ✅ tested (5 endpoints, verified with real + malformed requests)
- Batch scoring: ✅ tested (all 7,043 customers scored end-to-end)
- Dashboard: ✅ tested (valid HTML, real embedded data, renders in browser)
- Docker/Compose: ⚠️ written to spec, not build-tested (no Docker in this sandbox — verify with `docker compose build` before production use)

## 7. Suggested Next Steps (Beyond the 4-Week Plan)

- Replace the LTV heuristic target with real observed revenue once available.
- Add model monitoring: track prediction drift and retrain triggers (e.g. monthly).
- A/B test retention offers against the priority-score segments to validate the model's business impact, not just its statistical fit.
- Add authentication to the FastAPI service before exposing it beyond internal networks.
